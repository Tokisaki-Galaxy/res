﻿#include <AIStarter.h>
#include <AIStarter.h>
#include <Servo.h>

volatile int 路口标记;
volatile int 路口计数;
volatile int 红色识别次数;

void 线路1() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    原地左转();
    break;
   case 2:
    卸载();
    break;
   case 3:
    前进();
    break;
   case 4:
    前进();
    break;
   case 5:
    原地左转();
    break;
  }
}

void 线路2() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    原地左转();
    break;
   case 2:
    前进();
    break;
   case 3:
    卸载();
    break;
   case 4:
    前进();
    break;
   case 5:
    原地左转();
    break;
  }
}

void 线路3() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    原地左转();
    break;
   case 2:
    前进();
    break;
   case 3:
    前进();
    break;
   case 4:
    卸载();
    break;
   case 5:
    原地左转();
    break;
  }
}

Servo servo_7;
void 翻斗() {
  AIStarter_SmartBotTimerTaskDetach();
  servo_7.attach(7);
  servo_7.write(30);
  delay(1000);
  servo_7.detach();
  delay(1000);
  servo_7.attach(7);
  servo_7.write(0);
  delay(1000);
  servo_7.detach();
  AIStarter_SmartBotTimerTaskAttach();
}

void 电机控制(String 状态, int 速度) {
  if (状态 == "前进") {
    AIStarter_SmartBotSetMotor(MOTORL,速度);
    AIStarter_SmartBotSetMotor(MOTORR,速度);

  } else if (状态 == "巡线左转") {
    AIStarter_SmartBotSetMotor(MOTORL,(速度 / 3));
    AIStarter_SmartBotSetMotor(MOTORR,速度);
  } else if (状态 == "巡线右转") {
    AIStarter_SmartBotSetMotor(MOTORL,速度);
    AIStarter_SmartBotSetMotor(MOTORR,(速度 / 3));
  } else if (状态 == "原地左转") {
    AIStarter_SmartBotSetMotor(MOTORL,(0 - 速度));
    AIStarter_SmartBotSetMotor(MOTORR,速度);
  } else if (状态 == "原地右转") {
    AIStarter_SmartBotSetMotor(MOTORL,速度);
    AIStarter_SmartBotSetMotor(MOTORR,(0 - 速度));
  } else if (状态 == "后退") {
    AIStarter_SmartBotSetMotor(MOTORL,(0 - 速度));
    AIStarter_SmartBotSetMotor(MOTORR,(0 - 速度));
  } else if (状态 == "停车") {
    AIStarter_SmartBotSetMotor(MOTORL,速度);
    AIStarter_SmartBotSetMotor(MOTORR,速度);
  }
}

void 巡线() {
  if ((AIStarter_SmartBotGetIRModuleValue(IR1) == 1 && AIStarter_SmartBotGetIRModuleValue(IR6) == 1) && (AIStarter_SmartBotGetIRModuleValue(IR2) == 1 && AIStarter_SmartBotGetIRModuleValue(IR5) == 1)) {
    路口标记 = 1;
    电机控制("前进", 40);
    AIStarter_SmartBotSetLED(LED1,ON);
    AIStarter_SmartBotSetLED(LED2,ON);
    delay(100);
    AIStarter_SmartBotSetLED(LED1,OFF);
    AIStarter_SmartBotSetLED(LED2,OFF);

  } else if (AIStarter_SmartBotGetCarHeadOffset() >= 18) {
    电机控制("巡线右转", 40);
    delay(40);
    AIStarter_SmartBotSetLED(LED2,ON);
    while (AIStarter_SmartBotGetIRModuleValue(IR3) != 1) {
      电机控制("巡线右转", 30);
      delay(10);
    }
    AIStarter_SmartBotSetLED(LED2,OFF);
  } else if (AIStarter_SmartBotGetCarHeadOffset() > -18 && AIStarter_SmartBotGetCarHeadOffset() < 18) {
    电机控制("前进", 20);
  } else if (AIStarter_SmartBotGetCarHeadOffset() <= -18) {
    电机控制("巡线左转", 30);
    delay(40);
    AIStarter_SmartBotSetLED(LED1,ON);
    while (AIStarter_SmartBotGetIRModuleValue(IR4) != 1) {
      电机控制("巡线左转", 30);
    }
    delay(10);
    AIStarter_SmartBotSetLED(LED1,OFF);
  }
}

// 状态选择字符串
void 路口动作(String 状态) {
  for (int i = 1; i <= 300; i = i + (1)) {
    巡线();
    delay(1);
  }
  if (状态 == "左转") {
    电机控制("原地左转", 40);
    delay(300);
    while (AIStarter_SmartBotGetIRModuleValue(IR3) != 1) {
      电机控制("原地左转", 30);
    }

  } else if (状态 == "右转") {
    电机控制("原地右转", 40);
    delay(300);
    while (AIStarter_SmartBotGetIRModuleValue(IR4) != 1) {
      电机控制("原地右转", 30);
    }
  } else if (状态 == "停车") {
    电机控制("停车", 0);
  } else if (状态 == "前进") {
  }
  路口标记 = 0;
  路口计数 = 路口计数 + 1;
}

void 线路4() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    前进();
    break;
   case 2:
    卸载();
    break;
   case 3:
    前进();
    break;
   case 4:
    前进();
    break;
   case 5:
    前进();
    break;
   case 6:
    前进();
    break;
   case 7:
    前进();
    break;
  }
}

void 线路5() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    前进();
    break;
   case 2:
    前进();
    break;
   case 3:
    卸载();
    break;
   case 4:
    前进();
    break;
   case 5:
    前进();
    break;
   case 6:
    前进();
    break;
   case 7:
    前进();
    break;
  }
}

void 线路6() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    前进();
    break;
   case 2:
    前进();
    break;
   case 3:
    前进();
    break;
   case 4:
    原地左转();
    break;
   case 5:
    卸载();
    break;
   case 6:
    原地右转();
    break;
   case 7:
    前进();
    break;
   case 8:
    原地左转();
    break;
  }
}

void 前进() {
  路口动作("前进");
}

void 原地左转() {
  电机控制("前进", 20);
  delay(300);
  路口动作("左转");
}

void 原地右转() {
  电机控制("前进", 20);
  delay(300);
  路口动作("右转");
}

void 装载停车() {
  电机控制("前进", 20);
  delay(100);
  AIStarter_SmartBotSetLED(LED1,ON);
  AIStarter_SmartBotSetLED(LED2,ON);
  路口动作("停车");
  delay(2000);
  AIStarter_SmartBotSetLED(LED1,OFF);
  AIStarter_SmartBotSetLED(LED2,OFF);
}

void 卸载() {
  电机控制("前进", 20);
  delay(200);
  // 摆正车头
  for (int i = 1; i <= 200; i = i + (1)) {
    巡线();
    delay(1);
  }
  路口动作("停车");
  delay(1000);
  翻斗();
  delay(200);
  电机控制("前进", 20);
  delay(20);
  AIStarter_SmartBotSetColorSenor(COLORSENOR1,1);
  AIStarter_SmartBotSetColorSenor(COLORSENOR2,1);
}

void 回到起点终止程序() {
  // 摆正车头
  for (int i = 1; i <= 100; i = i + (1)) {
    巡线();
    delay(2);
  }
  电机控制("停车", 0);
  delay(1000);
  while(true);
}

void 线路7() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    原地左转();
    break;
   case 2:
    前进();
    break;
   case 3:
    原地右转();
    break;
   case 4:
    卸载();
    break;
   case 5:
    原地左转();
    break;
   case 6:
    前进();
    break;
   case 7:
    前进();
    break;
   case 8:
    前进();
    break;
  }
}

void 线路8() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    前进();
    break;
   case 2:
    前进();
    break;
   case 3:
    前进();
    break;
   case 4:
    前进();
    break;
   case 5:
    卸载();
    break;
   case 6:
    前进();
    break;
   case 7:
    前进();
    break;
  }
}

void 线路9() {
  switch (路口计数) {
   case 0:
    装载停车();
    break;
   case 1:
    前进();
    break;
   case 2:
    前进();
    break;
   case 3:
    前进();
    break;
   case 4:
    前进();
    break;
   case 5:
    前进();
    break;
   case 6:
    卸载();
    break;
   case 7:
    前进();
    break;
  }
}

void setup()
{
  路口标记 = 0;
  路口计数 = 0;
  红色识别次数 = 0;
  AIStarter_SmartBotInit();
  AIStarter_SmartBotInit();
  AIStarter_SmartBotSetMotor(MOTORL,20);
  AIStarter_SmartBotSetMotor(MOTORR,20);
  AIStarter_SmartBotTimerTaskDetach();
  delay(200);
  servo_7.attach(7);
  servo_7.write(0);
  delay(1000);
  servo_7.detach();
  delay(1000);
  AIStarter_SmartBotTimerTaskAttach();
  delay(100);
}

void loop()
{
  巡线();
  if (路口标记) {
    switch (红色识别次数) {
     case 0:
      线路1();
      break;
     case 1:
      线路2();
      break;
     case 2:
      线路3();
      break;
     case 3:
      线路4();
      break;
     case 4:
      线路5();
      break;
     case 5:
      线路6();
      break;
     case 6:
      线路7();
      break;
     case 7:
      线路8();
      break;
     case 8:
      线路9();
      break;
    }

  } else if (红色识别次数 > 8) {
    回到起点终止程序();
  }
  while (AIStarter_SmartBotDetColorSenor(COLORSENOR1,RCOLOR) && AIStarter_SmartBotDetColorSenor(COLORSENOR2,RCOLOR)) {
    for (int i = 1; i <= 500; i = i + (1)) {
      巡线();
      delay(1);
    }
    路口标记 = 0;
    路口计数 = 0;
    红色识别次数 = 红色识别次数 + 1;
  }

}