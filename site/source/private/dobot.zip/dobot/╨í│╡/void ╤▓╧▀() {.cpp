void 巡线() {
  if ((AIStarter_SmartBotGetIRModuleValue(IR1) == 1 && AIStarter_SmartBotGetIRModuleValue(IR6) == 1) && (AIStarter_SmartBotGetIRModuleValue(IR2) == 1 && AIStarter_SmartBotGetIRModuleValue(IR5) == 1)) {
    cross_flag = 1;

    AIStarter_SmartBotSetMotor(MOTORL,40);
    AIStarter_SmartBotSetMotor(MOTORR,40);

    AIStarter_SmartBotSetLED(LED1,ON);
    AIStarter_SmartBotSetLED(LED2,ON);
    delay(100);
    AIStarter_SmartBotSetLED(LED1,OFF);
    AIStarter_SmartBotSetLED(LED2,OFF);
  } else if (AIStarter_SmartBotGetCarHeadOffset() >= 18) {
    电机控制("巡线右转", 40);
    AIStarter_SmartBotSetMotor(MOTORL,40);
    AIStarter_SmartBotSetMotor(MOTORR,40);
    delay(40);
    AIStarter_SmartBotSetLED(LED2,ON);
    while (AIStarter_SmartBotGetIRModuleValue(IR3) != 1) {
      电机控制("巡线右转", 30);
      delay(10);
    }
    AIStarter_SmartBotSetLED(LED2,OFF);
  } else if (AIStarter_SmartBotGetCarHeadOffset() > -18 && AIStarter_SmartBotGetCarHeadOffset() < 18) {
    电机控制("前进", 20);
  } else if (AIStarter_SmartBotGetCarHeadOffset() <= -18) {
    电机控制("巡线左转", 30);
    delay(40);
    AIStarter_SmartBotSetLED(LED1,ON);
    while (AIStarter_SmartBotGetIRModuleValue(IR4) != 1) {
      电机控制("巡线左转", 30);
    }
    delay(10);
    AIStarter_SmartBotSetLED(LED1,OFF);
  }
}